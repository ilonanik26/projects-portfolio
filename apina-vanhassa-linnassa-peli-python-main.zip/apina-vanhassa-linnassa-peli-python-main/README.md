# apina-vanhassa-linnassa-peli-python
Python-tekstiseikkailupeli kurssin loppuharjoitustyö
